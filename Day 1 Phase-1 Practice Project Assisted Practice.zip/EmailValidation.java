import java.util.regex.*;

public class EmailValidation {
    public static void main(String[] args) {
        String email1 = "user@example.com";
        String email2 = "user123@example";

        System.out.println("Email 1: " + email1);
        if (isValidEmail(email1)) {
            System.out.println("Email 1 is valid");
        } else {
            System.out.println("Email 1 is invalid");
        }

        System.out.println("Email 2: " + email2);
        if (isValidEmail(email2)) {
            System.out.println("Email 2 is valid");
        } else {
            System.out.println("Email 2 is invalid");
        }
    }

    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}
