// Parent interface
interface Animal {
    void sound();
}

// First parent interface
interface Cat extends Animal {
    default void sound() {
        System.out.println("Meow");
    }
}

// Second parent interface
interface Dog extends Animal {
    default void sound() {
        System.out.println("Bark");
    }
}

// Child class implementing both interfaces
class CatDog implements Cat, Dog {
    public void sound() {
        Cat.super.sound(); // Resolves the diamond problem by explicitly invoking the Cat interface's sound() method
        Dog.super.sound(); // Resolves the diamond problem by explicitly invoking the Dog interface's sound() method
    }
}

public class DiamondProblem {
    public static void main(String[] args) {
        CatDog catDog = new CatDog();
        catDog.sound();
    }
}
