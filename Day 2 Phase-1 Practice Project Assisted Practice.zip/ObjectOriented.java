// Parent class
class Animal {
    protected String name;

    public Animal(String name) {
        this.name = name;
    }

    public void sound() {
        System.out.println("The animal makes a sound.");
    }
}

// Child class inheriting from Animal
class Dog extends Animal {
    public Dog(String name) {
        super(name);
    }

    @Override
    public void sound() {
        System.out.println(name + " barks.");
    }

    public void fetch() {
        System.out.println(name + " fetches the ball.");
    }
}

// Another child class inheriting from Animal
class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }

    @Override
    public void sound() {
        System.out.println(name + " meows.");
    }

    public void scratch() {
        System.out.println(name + " scratches.");
    }
}

public class ObjectOriented {
    public static void main(String[] args) {
        // Creating objects of the classes
        Dog dog = new Dog("Buddy");
        Cat cat = new Cat("Whiskers");

        // Polymorphism
        Animal animal1 = dog;
        Animal animal2 = cat;

        // Method calls using objects
        dog.sound(); // Dog class method
        cat.sound(); // Cat class method

        dog.fetch(); // Dog class method
        cat.scratch(); // Cat class method

        // Encapsulation
        dog.name = "Max"; // Direct access to the protected variable

        // Inheritance
        System.out.println(animal1.name + " is a dog.");
        System.out.println(animal2.name + " is a cat.");

        // Polymorphism
        animal1.sound(); // Dog class method
        animal2.sound(); // Cat class method
    }
}
