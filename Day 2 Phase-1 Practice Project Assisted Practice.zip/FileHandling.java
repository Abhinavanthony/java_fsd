import java.io.*;

public class FileHandling {
    public static void main(String[] args) {
        String fileName = "example.txt";

        // Write to file
        writeToFile(fileName, "Hello, World!");

        // Read from file
        String content = readFromFile(fileName);
        System.out.println("File content: " + content);

        // Append to file
        appendToFile(fileName, " This is additional content.");

        // Read again from file
        content = readFromFile(fileName);
        System.out.println("Updated file content: " + content);
    }

    public static void writeToFile(String fileName, String content) {
        try (FileWriter writer = new FileWriter(fileName)) {
            writer.write(content);
            System.out.println("Successfully wrote to file: " + fileName);
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    public static String readFromFile(String fileName) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
        return content.toString();
    }

    public static void appendToFile(String fileName, String content) {
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.write(content);
            System.out.println("Successfully appended to file: " + fileName);
        } catch (IOException e) {
            System.out.println("An error occurred while appending to the file: " + e.getMessage());
        }
    }
}
