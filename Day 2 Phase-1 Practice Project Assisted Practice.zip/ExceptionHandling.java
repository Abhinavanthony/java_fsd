public class ExceptionHandling {
    public static void main(String[] args) {
        try {
            int result = divideNumbers(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero");
        } catch (CustomException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static int divideNumbers(int dividend, int divisor) throws CustomException {
        try {
            if (divisor == 0) {
                throw new CustomException("Divisor cannot be zero.");
            }
            return dividend / divisor;
        } catch (ArithmeticException e) {
            throw e;
        }
    }
}

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}
