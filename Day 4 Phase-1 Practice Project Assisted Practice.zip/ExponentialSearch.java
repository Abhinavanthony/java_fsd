public class ExponentialSearch {

    public static int exponentialSearch(int[] array, int target) {
        int size = array.length;
        
        // If the target element is present at the first position
        if (array[0] == target) {
            return 0;
        }
        
        // Find the range for binary search by doubling the index
        int i = 1;
        while (i < size && array[i] <= target) {
            i *= 2;
        }
        
        // Perform binary search in the identified range
        int left = i / 2;
        int right = Math.min(i, size - 1);
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (array[mid] == target) {
                return mid;  // Return the index of the target element
            } else if (array[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        
        return -1;  // Return -1 if the target element is not found
    }

    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 7, 9};
        int target = 7;
        int index = exponentialSearch(array, target);

        if (index != -1) {
            System.out.println("Element " + target + " found at index " + index);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }
    }
}
