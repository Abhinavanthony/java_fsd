
import java.util.Arrays;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int rotationSteps = 5;

        System.out.println("Original array: " + Arrays.toString(array));

        rightRotateArray(array, rotationSteps);

        System.out.println("Right rotated array: " + Arrays.toString(array));
    }

    private static void rightRotateArray(int[] array, int rotationSteps) {
        int length = array.length;
        rotationSteps %= length;  // Adjust rotation steps if greater than array length

        reverseArray(array, 0, length - 1);  // Reverse the entire array
        reverseArray(array, 0, rotationSteps - 1);  // Reverse the first part
        reverseArray(array, rotationSteps, length - 1);  // Reverse the second part
    }

    private static void reverseArray(int[] array, int start, int end) {
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }
}
