import java.util.Arrays;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {9, 2, 7, 4, 5, 1, 8, 3, 6};
        
        int fourthSmallest = findFourthSmallestElement(unsortedList);

        System.out.println("Unsorted list: " + Arrays.toString(unsortedList));
        System.out.println("Fourth smallest element: " + fourthSmallest);
    }

    private static int findFourthSmallestElement(int[] unsortedList) {
        if (unsortedList.length < 4) {
            throw new IllegalArgumentException("List should have at least 4 elements.");
        }

        Arrays.sort(unsortedList);  // Sort the list in ascending order

        return unsortedList[3];  // Return the fourth element
    }
}
