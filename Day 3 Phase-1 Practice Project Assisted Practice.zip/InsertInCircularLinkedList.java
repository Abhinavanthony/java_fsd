class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    void insert(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
            return;
        }

        Node current = head;

        // Case 1: Insert at the beginning (new element is smaller than head)
        if (newData < head.data) {
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            newNode.next = head;
            head = newNode;
            return;
        }

        // Case 2: Insert in the middle or at the end
        while (current.next != head && current.next.data < newData) {
            current = current.next;
        }
        newNode.next = current.next;
        current.next = newNode;
    }

    void printList() {
        if (head == null) {
            return;
        }

        Node current = head;

        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }
}

public class InsertInCircularLinkedList {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList();

        circularList.insert(1);
        circularList.insert(3);
        circularList.insert(5);
        circularList.insert(7);

        System.out.println("Circular Linked List:");
        circularList.printList();
    }
}
